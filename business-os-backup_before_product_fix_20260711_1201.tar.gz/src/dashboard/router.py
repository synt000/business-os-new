import os

from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from src.core.database import get_db
from src.core.security import get_current_user
from src.services.dashboard_service import DashboardService
from src.models.saas_core import User


router = APIRouter(
    tags=["Enterprise Dashboard"]
)


BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


templates = Jinja2Templates(
    directory=os.path.join(
        BASE_DIR,
        "templates"
    )
)



@router.get("/", response_class=HTMLResponse)
async def home(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="index.html"
    )



@router.get("/login", response_class=HTMLResponse)
async def login(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="login.html"
    )



@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="dashboard.html"
    )



@router.get(
    "/api/v4/dashboard/summary"
)
async def dashboard_summary(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):

    return DashboardService.get_summary(
        db,
        current_user.tenant_id
    )



@router.get("/products/ui", response_class=HTMLResponse)
async def products_ui(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="products.html"
    )



@router.get("/inventory/ui", response_class=HTMLResponse)
async def inventory_ui(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="inventory.html"
    )



@router.get("/orders/ui", response_class=HTMLResponse)
async def orders_ui(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="orders.html"
    )



@router.get("/customers/ui", response_class=HTMLResponse)
async def customers_ui(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="customers.html"
    )



@router.get("/suppliers/ui", response_class=HTMLResponse)
async def suppliers_ui(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="suppliers.html"
    )


@router.get("/customers/ui", response_class=HTMLResponse)
async def customers_ui(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="customers.html"
    )


@router.get("/suppliers/ui", response_class=HTMLResponse)
async def suppliers_ui(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="suppliers.html"
    )


@router.get("/customers/ui", response_class=HTMLResponse)
async def customers_ui(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="customers.html"
    )


@router.get("/suppliers/ui", response_class=HTMLResponse)
async def suppliers_ui(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="suppliers.html"
    )

